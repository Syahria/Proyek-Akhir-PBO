/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Laden
 */
public class Database {

    private final static String dbhost = "localhost";
    private final static String dbname = "databasehotel";
    private final static String username = "root";
    private final static String password = ""; // kosongkan jika memang tidak pakai password

    protected Connection connection = null;
    protected Statement statement;
    protected PreparedStatement preparedStatement;
    protected ResultSet resultSet;

    protected final void openConnection() {
        try {
            this.connection = DriverManager.getConnection(
                    "jdbc:mysql://" + Database.dbhost
                    + "/" + Database.dbname
                    + "?user=" + Database.username
                    + "&password=" + Database.password
            );
        } catch (SQLException ex) {
            this.displayErrors(ex);
        }
    }
    
    protected final void closeConnection(){
        try {
            if(this.resultSet != null) this.resultSet.close();
            if(this.statement != null) this.statement.close();
            if(this.preparedStatement != null) this.preparedStatement.close();
            if(this.connection != null) this.connection.close();
            
            this.resultSet = null;
            this.statement = null;
            this.preparedStatement = null;
            this.connection = null;
            
        } catch (SQLException ex) {
            this.displayErrors(ex);
        }
    }
    protected final void displayErrors(SQLException ex){
        System.out.println("SQLException : "+ ex.getMessage());
        System.out.println("SQLState : "+ ex.getSQLState());
        System.out.println("VendorError : "+ ex.getErrorCode());
    }
    
    protected final int getLastId(){
        try {
            if(this.statement != null){
                this.resultSet = this.statement.getGeneratedKeys();
            }
            if (this.preparedStatement != null) {
                this.resultSet = this.preparedStatement.getGeneratedKeys();
            }
            if(this.resultSet.next()){
                return resultSet.getInt(1);
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        }
        return 0;
    }
    
    protected final ArrayList<ArrayList> all(String query){
        ArrayList<ArrayList> rows = new ArrayList();
        try {
            this.statement = this.connection.createStatement();
            this.resultSet = this.statement.executeQuery(query);
            
            while(this.resultSet.next()){
                ResultSetMetaData rsMetaData = this.resultSet.getMetaData();
                int columnCount = rsMetaData.getColumnCount();
                ArrayList<String> columns = new ArrayList();
                
                for (int i = 1; i <= columnCount; i++) {
                    columns.add(this.resultSet.getString(i));
                }
                rows.add(columns);
            }
            
        } catch (SQLException ex) {
            this.displayErrors(ex);
        }
        return rows;
    }
    protected final void runQuery(String query){
        try {
            this.statement = this.connection.createStatement();
            this.statement.executeUpdate(query);
            System.out.println("Query berhasil dijalankan");
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } 
    }
}
