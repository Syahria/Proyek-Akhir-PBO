/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Laden
 */
public class KamarSuite extends Kamar {

    private String layanan_gratis;

    @Override
    public boolean create() {
        boolean isCreated = false;
        try {
            super.create(); // buat data kamar dulu
            this.openConnection();
            String sql = "INSERT INTO kamar_suite (id_kamar,layanan_gratis) VALUES (?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(1, super.id);
            this.preparedStatement.setString(2, this.layanan_gratis);
            this.preparedStatement.executeUpdate();
            this.id = super.id;
            isCreated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isCreated;
    }

    // Membuat fitur update
    @Override
    public boolean update() {
        boolean isUpdated = false;
        try {
            super.update();
            this.openConnection();
            String sql = "UPDATE kamar_suite SET "
                    + "layanan_gratis=?"
                    + " WHERE id_kamar=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setString(1, this.layanan_gratis);
            this.preparedStatement.setInt(1, super.id); // mengambil id dari kelas parent
            this.preparedStatement.executeUpdate();
            isUpdated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isUpdated;
    }

    // Membuat fitur delete
    @Override
    public boolean delete() {
        boolean isDeleted = false;
        try {
            super.delete();
            this.openConnection();
            String sql = "DELETE FROM kamar_suite WHERE id=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(2, super.id);
            this.preparedStatement.executeUpdate();
            isDeleted = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isDeleted;
    }

//    @Override
//    public boolean find(String lantai, String kamar) {
//        boolean isExist = false;
//        try {
//            this.openConnection();
//            this.preparedStatement = this.connection.prepareStatement("SELECT * FROM kamar_suite WHERE id_kamar=?");
//            this.preparedStatement.setInt(1, super.id);
//            this.resultSet = this.preparedStatement.executeQuery();
//
//            if (this.resultSet.next()) {
//                this.layanan_gratis = this.resultSet.getString("layanan_gratis");
//                isExist = true;
//            }
//        } catch (SQLException ex) {
//            this.displayErrors(ex);
//        } finally {
//            this.closeConnection();
//        }
//        return isExist;
//    }

    @Override
    public ArrayList<ArrayList> getAll() {
        this.openConnection();
        ArrayList<ArrayList> data = this.all("SELECT kamar_hotel.*,kamar_suite.layanan_gratis "
                + "FROM kamar_hotel "
                + "INNER JOIN kamar_suite ON kamar_suite.id_kamar = kamar_hotel.id_kamar ");
        this.closeConnection();
        return data;
    }

    public String getLayanan_gratis() {
        return layanan_gratis;
    }

    public void setLayanan_gratis(String layanan_gratis) {
        this.layanan_gratis = layanan_gratis;
    }

}
