/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Laden
 */
public class Tamu extends Database implements TemplateCRUD {

    private int id,id_reservasi;
    private String nama, alamat, telepon;

    @Override
    public boolean create() {
        boolean isCreated = false;
        try {
            this.openConnection();
            String sql = "INSERT INTO tamu (nama_tamu,alamat,no_telepon,reservasi_id_reservasi) VALUES (?,?,?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            this.preparedStatement.setString(1, this.nama);
            this.preparedStatement.setString(2, this.alamat);
            this.preparedStatement.setString(3, this.telepon);
            this.preparedStatement.setInt(4, this.id_reservasi);
            this.preparedStatement.executeUpdate();
            this.id = this.getLastId();
            isCreated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isCreated;
    }

    @Override
    public boolean update() {
        boolean isUpdated = false;
        try {
            this.openConnection();
            String sql = "UPDATE tamu SET "
                    + "nama_tamu=?,"
                    + "alamat=?,"
                    + "no_telepon=? "
                    + " WHERE id_tamu=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setString(1, this.nama);
            this.preparedStatement.setString(2, this.alamat);
            this.preparedStatement.setString(3, this.telepon);
            this.preparedStatement.setInt(4, this.id);
            this.preparedStatement.executeUpdate();
            isUpdated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isUpdated;
    }

    @Override
    public boolean delete() {
        boolean isDeleted = false;
        try {
            this.openConnection();
            String sql = "DELETE FROM tamu WHERE id_tamu=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(1, this.id);
            this.preparedStatement.executeUpdate();
            isDeleted = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isDeleted;
    }

    @Override
    public boolean find(int id) {
        boolean isExist = false;
        try {
            this.openConnection();
            this.preparedStatement = this.connection.prepareStatement("SELECT * FROM tamu WHERE id_tamu=?");
            this.preparedStatement.setInt(1, id);
            this.resultSet = this.preparedStatement.executeQuery();

            if (this.resultSet.next()) {
                this.id = this.resultSet.getInt("id_tamu");
                this.nama = this.resultSet.getString("nama_tamu");
                this.alamat = this.resultSet.getString("alamat");
                this.telepon = this.resultSet.getString("no_telepon");
                isExist = true;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isExist;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getTelepon() {
        return telepon;
    }

    public void setTelepon(String telepon) {
        this.telepon = telepon;
    }

    public int getId_reservasi() {
        return id_reservasi;
    }

    public void setId_reservasi(int id_reservasi) {
        this.id_reservasi = id_reservasi;
    }

}
