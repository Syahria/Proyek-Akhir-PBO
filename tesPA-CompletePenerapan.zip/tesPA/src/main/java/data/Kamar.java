/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Laden
 */
public class Kamar extends Database implements TemplateCRUD {

    int id, id_pegawai;
    String lantai, harga, no_kamar, fasilitas, status;

    // Membuat fitur create
    @Override
    public boolean create() {
        boolean isCreated = false;
        try {
            this.openConnection();
            String sql = "INSERT INTO kamar_hotel (lantai,no_kamar,harga,fasilitas,status,pegawai_id_pegawai) VALUES (?,?,?,?,?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            this.preparedStatement.setString(1, this.lantai);
            this.preparedStatement.setString(2, this.no_kamar);
            this.preparedStatement.setString(3, this.harga);
            this.preparedStatement.setString(4, this.fasilitas);
            this.preparedStatement.setString(5, this.status);
            this.preparedStatement.setInt(6, this.id_pegawai);
            this.preparedStatement.executeUpdate();
            this.id = this.getLastId();
            isCreated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isCreated;
    }

    // Membuat fitur update
    @Override
    public boolean update() {
        boolean isUpdated = false;
        try {
            this.openConnection();
            String sql = "UPDATE kamar_hotel SET "
                    + "lantai=?,"
                    + "no_kamar=?,"
                    + "harga=?,"
                    + "fasilitas=?,"
                    + "status=? "
                    + " WHERE id_kamar=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setString(1, this.lantai);
            this.preparedStatement.setString(2, this.no_kamar);
            this.preparedStatement.setString(3, this.harga);
            this.preparedStatement.setString(4, this.fasilitas);
            this.preparedStatement.setString(5, this.status);
            this.preparedStatement.setInt(6, this.id);
            this.preparedStatement.executeUpdate();
            isUpdated = true;
            System.out.println("berhasil");
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isUpdated;
    }

    // Membuat fitur delete
    @Override
    public boolean delete() {
        boolean isDeleted = false;
        try {
            this.openConnection();
            String sql = "DELETE FROM kamar_hotel WHERE id_kamar=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(1, this.id);
            this.preparedStatement.executeUpdate();
            isDeleted = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isDeleted;
    }

    @Override
    public boolean find(int id) {
        boolean isExist = false;
        try {
            this.openConnection();
            this.preparedStatement = this.connection.prepareStatement("SELECT * FROM kamar_hotel WHERE id_kamar=?");
            this.preparedStatement.setInt(1, id);
            this.resultSet = this.preparedStatement.executeQuery();

            if (this.resultSet.next()) {
                this.id = this.resultSet.getInt("id_kamar");
                this.lantai = this.resultSet.getString("lantai");
                this.no_kamar = this.resultSet.getString("no_kamar");
                this.harga = this.resultSet.getString("harga");
                this.fasilitas = this.resultSet.getString("fasilitas");
                this.status = this.resultSet.getString("status");
                isExist = true;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isExist;
    }

    public boolean find(String lantai, String nomor) {
        boolean isExist = false;
        try {
            this.openConnection();
            this.preparedStatement = this.connection.prepareStatement("SELECT * FROM kamar_hotel WHERE lantai=? AND no_kamar=?");
            this.preparedStatement.setString(1, lantai);
            this.preparedStatement.setString(2, nomor);
            this.resultSet = this.preparedStatement.executeQuery();

            if (this.resultSet.next()) {
                this.id = this.resultSet.getInt("id_kamar");
                this.lantai = this.resultSet.getString("lantai");
                this.no_kamar = this.resultSet.getString("no_kamar");
                this.harga = this.resultSet.getString("harga");
                this.fasilitas = this.resultSet.getString("fasilitas");
                this.status = this.resultSet.getString("status");
                isExist = true;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isExist;
    }

    public ArrayList<ArrayList> getAll() {
        this.openConnection();
        ArrayList<ArrayList> data = this.all("SELECT * FROM kamar_hotel");
        this.closeConnection();
        return data;
    }

    public ArrayList<ArrayList> getTotalLantai() {
        this.openConnection();
        ArrayList<ArrayList> data = this.all(String.format("SELECT DISTINCT lantai FROM kamar_hotel"));
        this.closeConnection();
        return data;
    }

    public ArrayList<ArrayList> getKamarOpen(String lantai, String tipe) {
        if(tipe.equals("Standard")){
            tipe = "kamar_standard";
        } else {
            tipe = "kamar_suite";
        }
        this.openConnection();
        ArrayList<ArrayList> data = this.all(String.format("SELECT kamar_hotel.*, %s.* FROM kamar_hotel INNER JOIN %s ON kamar_hotel.id_kamar = %s.id_kamar WHERE lantai='%s' AND status='Open'", tipe,tipe,tipe, lantai));
        this.closeConnection();
        return data;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getLantai() {
        return lantai;
    }

    public void setLantai(String lantai) {
        this.lantai = lantai;
    }

    public String getNo_kamar() {
        return no_kamar;
    }

    public void setNo_kamar(String no_kamar) {
        this.no_kamar = no_kamar;
    }

    public String getFasilitas() {
        return fasilitas;
    }

    public void setFasilitas(String fasilitas) {
        this.fasilitas = fasilitas;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getId_pegawai() {
        return id_pegawai;
    }

    public void setId_pegawai(int id_pegawai) {
        this.id_pegawai = id_pegawai;
    }

}
