/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Laden
 */
public class Transaksi extends Database implements TemplateCRUD {
    private int id,id_reservasi,id_pegawai;
    private String total_harga,status;
    
    @Override
    public boolean create() {
        boolean isCreated = false;
        try {
            this.openConnection();
            String sql = "INSERT INTO transaksi (reservasi_id_reservasi,total_harga,status,pegawai_id_pegawai) VALUES (?,?,'unpaid',?)";
            this.preparedStatement = this.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            this.preparedStatement.setInt(1, this.id_reservasi);
            this.preparedStatement.setString(2, this.total_harga);
            this.preparedStatement.setInt(3, this.id_pegawai);
            this.preparedStatement.executeUpdate();
            this.id = this.getLastId();
            isCreated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isCreated;
    }

    @Override
    public boolean update() {
        boolean isUpdated = false;
        try {
            this.openConnection();
            String sql = "UPDATE transaksi SET "
                    + "total_harga=?"
                    + " WHERE id_transaksi=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setString(1, this.total_harga);
            this.preparedStatement.setInt(2, this.id);
            this.preparedStatement.executeUpdate();
            isUpdated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isUpdated;
    }

    @Override
    public boolean delete() {
        boolean isDeleted = false;
        try {
            this.openConnection();
            String sql = "DELETE FROM transaksi WHERE id_transaksi=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(1, this.id);
            this.preparedStatement.executeUpdate();
            isDeleted = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isDeleted;
    }

    @Override
    public boolean find(int id_reservasi) {
        boolean isExist = false;
        try {
            this.openConnection();
            this.preparedStatement = this.connection.prepareStatement("SELECT * FROM transaksi WHERE reservasi_id_reservasi=?");
            this.preparedStatement.setInt(1, id_reservasi);
            this.resultSet = this.preparedStatement.executeQuery();

            if (this.resultSet.next()) {
                this.id = this.resultSet.getInt("id_transaksi");
                this.total_harga = this.resultSet.getString("total_harga");
                this.id_reservasi = this.resultSet.getInt("reservasi_id_reservasi");
                this.id_pegawai = this.resultSet.getInt("pegawai_id_pegawai");
                isExist = true;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isExist;
    }
    public boolean checkOut() {
        boolean isCheckOut = false;
        try {
            this.openConnection();
            String sql = "UPDATE transaksi SET "
                    + "status='paid' "
                    + " WHERE id_transaksi=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(1, this.id);
            this.preparedStatement.executeUpdate();
            isCheckOut = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isCheckOut;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_reservasi() {
        return id_reservasi;
    }

    public void setId_reservasi(int id_reservasi) {
        this.id_reservasi = id_reservasi;
    }

    public String getTotal_harga() {
        return total_harga;
    }

    public void setTotal_harga(String total_harga) {
        this.total_harga = total_harga;
    }

    public int getId_pegawai() {
        return id_pegawai;
    }

    public void setId_pegawai(int id_pegawai) {
        this.id_pegawai = id_pegawai;
    }
    
}
