/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Laden
 */
public class Reservasi extends Database implements TemplateCRUD {

    private int id, id_pegawai, id_kamar;
    private String tanggal_checkin, tanggal_checkout;
    private Transaksi transaksi;
    private Tamu tamu;
    private Kamar kamar;
    private SimpleDateFormat dateFormat;

    public Reservasi() {
        this.tamu = new Tamu();
        this.kamar = new Kamar();
    }
    // Overloading
    public Reservasi(Tamu tamu) {
        this.tamu = tamu;
        this.kamar = new Kamar();
        this.dateFormat = new SimpleDateFormat("yyyy/MM/dd");
    }
    // Overloading
    public Reservasi(Tamu tamu, Kamar kamar) {
        this.tamu = tamu;
        this.kamar = kamar;
        this.dateFormat = new SimpleDateFormat("yyyy/MM/dd");
    }

    @Override
    public boolean create() {
        boolean isCreated = true;
        try {
            this.openConnection();
            String sql = "INSERT INTO reservasi (kamar_hotel_id_kamar,tgl_checkin,tgl_checkout,pegawai_id_pegawai) VALUES (?,?,?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            this.preparedStatement.setInt(1, this.kamar.getId());
            this.preparedStatement.setString(2, this.tanggal_checkin);
            this.preparedStatement.setString(3, this.tanggal_checkout);
            this.preparedStatement.setInt(4, this.id_pegawai);
            this.preparedStatement.executeUpdate();
            this.id = this.getLastId();

            // input data Tamu
            tamu.setId_reservasi(this.id);
            if (!tamu.create()) {
                isCreated = false;
            }

            // ubah status kamar
            kamar.setStatus("Booked");
            if (!kamar.update()) {
                isCreated = false;
            }

            // input data transaksi
            transaksi = new Transaksi();
            // mencari total hari
            Date startDate = dateFormat.parse(this.tanggal_checkin);
            Date endDate = dateFormat.parse(this.tanggal_checkout);
            // Menghitung selisih dalam milidetik
            long timeDiff = endDate.getTime() - startDate.getTime();
            // Menghitung total hari
            long daysDiff = timeDiff / (24 * 60 * 60 * 1000);
            long total_harga = (daysDiff + 1) * Long.parseLong(this.kamar.getHarga()); // plus 1 untuk default 1 malam
            transaksi.setId_reservasi(this.id);
            transaksi.setTotal_harga(Long.toString(total_harga));
            transaksi.setId_pegawai(id_pegawai);
            if (!transaksi.create()) {
                isCreated = false;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } catch (ParseException ex) {
            Logger.getLogger(Reservasi.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            this.closeConnection();
        }
        return isCreated;
    }

    @Override
    public boolean update() {
        boolean isUpdated = true;
        try {
            // update data tamu, checkout, status kamar, total_harga
            this.openConnection();
            String sql = "UPDATE reservasi SET "
                    + "tgl_checkout=? "
                    + " WHERE id_reservasi=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setString(1, this.tanggal_checkout);
            this.preparedStatement.setInt(2, this.id);
            this.preparedStatement.executeUpdate();

            // input data Tamu
            if (!tamu.update()) {
                isUpdated = false;
            }

            // input data transaksi
            transaksi = new Transaksi();
            // mencari total hari
            Date startDate = dateFormat.parse(this.tanggal_checkin);
            Date endDate = dateFormat.parse(this.tanggal_checkout);
            // Menghitung selisih dalam milidetik
            long timeDiff = endDate.getTime() - startDate.getTime();
            // Menghitung total hari
            long daysDiff = timeDiff / (24 * 60 * 60 * 1000);
            long total_harga = (daysDiff + 1) * Long.parseLong(this.kamar.getHarga()); // plus 1 untuk default 1 malam
            transaksi.find(this.id);
            transaksi.setTotal_harga(Long.toString(total_harga));
            System.out.println("total harga : "+total_harga);
            if (!transaksi.update()) {
                isUpdated = false;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } catch (ParseException ex) {
            Logger.getLogger(Reservasi.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            this.closeConnection();
        }
        return isUpdated;
    }

    @Override
    public boolean delete() {
        boolean isDeleted = false;
        try {
            this.openConnection();
            String sql = "DELETE FROM reservasi WHERE id_reservasi=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(1, this.id);
            this.preparedStatement.executeUpdate();
            isDeleted = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isDeleted;
    }

    @Override
    public boolean find(int id) {
        boolean isExist = false;
        try {
            this.openConnection();
            this.preparedStatement = this.connection.prepareStatement("SELECT * FROM reservasi WHERE id_reservasi=?");
            this.preparedStatement.setInt(1, id);
            this.resultSet = this.preparedStatement.executeQuery();
            if (this.resultSet.next()) {
                this.id = this.resultSet.getInt("id_reservasi");
                this.id_kamar = this.resultSet.getInt("kamar_hotel_id_kamar");
                this.tanggal_checkin = this.resultSet.getString("tgl_checkin");
                this.tanggal_checkout = this.resultSet.getString("tgl_checkout");
                this.kamar.find(this.resultSet.getInt("kamar_hotel_id_kamar"));
                isExist = true;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isExist;
    }

    public  ArrayList<ArrayList> getAll(String status) {
        this.openConnection();
        ArrayList<ArrayList> data = this.all("SELECT reservasi.id_reservasi, kamar_hotel.lantai, kamar_hotel.no_kamar,"
                + "tamu.id_tamu,tamu.nama_tamu, tamu.alamat, tamu.no_telepon,"
                + "reservasi.tgl_checkin, reservasi.tgl_checkout,"
                + "transaksi.total_harga,pegawai.nama_pegawai "
                + "FROM tamu "
                + "INNER JOIN reservasi ON tamu.reservasi_id_reservasi = reservasi.id_reservasi "
                + "INNER JOIN kamar_hotel ON reservasi.kamar_hotel_id_kamar = kamar_hotel.id_kamar "
                + "INNER JOIN transaksi ON transaksi.reservasi_id_reservasi = reservasi.id_reservasi "
                + "INNER JOIN pegawai ON reservasi.pegawai_id_pegawai = pegawai.id_pegawai WHERE transaksi.status='"+status+"'");
        this.closeConnection();
        return data;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTanggal_checkin() {
        return tanggal_checkin;
    }

    public void setTanggal_checkin(String tanggal_checkin) {
        this.tanggal_checkin = tanggal_checkin;
    }

    public String getTanggal_checkout() {
        return tanggal_checkout;
    }

    public void setTanggal_checkout(String tanggal_checkout) {
        this.tanggal_checkout = tanggal_checkout;
    }

    public int getId_pegawai() {
        return id_pegawai;
    }

    public void setId_pegawai(int id_pegawai) {
        this.id_pegawai = id_pegawai;
    }

    public int getId_kamar() {
        return id_kamar;
    }

    public void setId_kamar(int id_kamar) {
        this.id_kamar = id_kamar;
    }

}
