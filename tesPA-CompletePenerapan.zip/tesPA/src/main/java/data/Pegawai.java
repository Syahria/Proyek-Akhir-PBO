/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Laden
 */
public class Pegawai extends Database implements TemplateCRUD {
    // Penerapan Static
    public static int idUserLogin = 0;
    public static String namaUserLogin = "User";
    
    private int id;
    private int id_atasan;
    private String nama;
    private String telepon;
    private String alamat;
    private String jabatan;

    
//  Membuat fitur create
    @Override
    public boolean create() {
        boolean isCreated = false;
        try {
            this.openConnection();
            String sql = "INSERT INTO pegawai (nama_pegawai,no_telepon,alamat,jabatan) VALUES (?,?,?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            this.preparedStatement.setString(1, this.nama);
            this.preparedStatement.setString(2, this.jabatan);
            this.preparedStatement.setString(3, this.telepon);
            this.preparedStatement.setString(4, this.alamat);
            this.preparedStatement.executeUpdate();
            this.id = this.getLastId();
            isCreated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isCreated;
    }
//  Membuat fitur login

    public boolean login(String id, String nama) {
        boolean isExist = false;
        try {
            this.openConnection();
            this.preparedStatement = this.connection.prepareStatement("SELECT * FROM pegawai WHERE id_pegawai =? AND nama_pegawai=?");
            this.preparedStatement.setString(1, id);
            this.preparedStatement.setString(2, nama);
            this.resultSet = this.preparedStatement.executeQuery();

            if (this.resultSet.next()) {
                this.id = this.resultSet.getInt("id_pegawai");
                this.nama = this.resultSet.getString("nama_pegawai");
                this.telepon = this.resultSet.getString("no_telepon");
                this.alamat = this.resultSet.getString("alamat");
                this.jabatan = this.resultSet.getString("jabatan");
                this.id_atasan = this.resultSet.getInt("pegawai_id_pegawai");
                isExist = true;
                idUserLogin = this.id;
                namaUserLogin = this.nama;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isExist;
    }
//    Membuat Getter dan Setter

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getJabatan() {
        return jabatan;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }

    public String getTelepon() {
        return telepon;
    }

    public void setTelepon(String noTelepon) {
        this.telepon = noTelepon;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public int getId_atasan() {
        return id_atasan;
    }

    public void setId_atasan(int id_atasan) {
        this.id_atasan = id_atasan;
    }

    @Override
    public boolean update() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean delete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean find(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
