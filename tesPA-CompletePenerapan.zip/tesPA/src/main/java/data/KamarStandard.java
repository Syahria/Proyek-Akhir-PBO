/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Laden
 */
public class KamarStandard extends Kamar {

    private String kapasitas;

    @Override
    public boolean create() {
        boolean isCreated = false;
        try {
            super.create(); // buat data kamar dulu
            this.openConnection();
            String sql = "INSERT INTO kamar_standard (id_kamar,kapasitas) VALUES (?,?)";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(1, super.id);
            this.preparedStatement.setString(2, this.kapasitas);
            this.preparedStatement.executeUpdate();
            this.id = super.id;
            isCreated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isCreated;
    }

    // Membuat fitur update
    @Override
    public boolean update() {
        boolean isUpdated = false;
        try {
            super.update();
            this.openConnection();
            String sql = "UPDATE kamar_standard SET "
                    + "kapasitas=?"
                    + " WHERE id_kamar=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setString(1, this.kapasitas);
            this.preparedStatement.setInt(2, super.id); // mengambil id dari kelas parent
            this.preparedStatement.executeUpdate();
            isUpdated = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isUpdated;
    }

    // Membuat fitur delete
    @Override
    public boolean delete() {
        boolean isDeleted = false;
        try {
            super.delete();
            this.openConnection();
            String sql = "DELETE FROM kamar_standard WHERE id_kamar=?";
            this.preparedStatement = this.connection.prepareStatement(sql);
            this.preparedStatement.setInt(1, super.id);
            this.preparedStatement.executeUpdate();
            isDeleted = true;
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            this.closeConnection();
        }
        return isDeleted;
    }

//    @Override
//    public boolean find(String lantai, String kamar) {
//        boolean isExist = false;
//        try {
//            super.find(lantai, kamar);
//            this.openConnection();
//            this.preparedStatement = this.connection.prepareStatement("SELECT * FROM kamar_standard WHERE id_kamar=?");
//            this.preparedStatement.setInt(1, super.id);
//            this.resultSet = this.preparedStatement.executeQuery();
//
//            if (this.resultSet.next()) {
//                this.kapasitas = this.resultSet.getString("kapasitas");
//                isExist = true;
//            }
//        } catch (SQLException ex) {
//            this.displayErrors(ex);
//        } finally {
//            this.closeConnection();
//        }
//        return isExist;
//    }

    @Override
    public ArrayList<ArrayList> getAll() {
        this.openConnection();
        ArrayList<ArrayList> data = this.all("SELECT kamar_hotel.*,kamar_standard.kapasitas "
                + "FROM kamar_hotel "
                + "INNER JOIN kamar_standard ON kamar_standard.id_kamar = kamar_hotel.id_kamar ");
        this.closeConnection();
        return data;
    }

    public String getKapasitas() {
        return kapasitas;
    }

    public void setKapasitas(String kapasitas) {
        this.kapasitas = kapasitas;
    }
}
